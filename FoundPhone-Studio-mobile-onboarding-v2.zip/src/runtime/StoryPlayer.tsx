import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { Phone } from "../Phone";
import { validateWork, type Work } from "../schema";
import "../styles.css";
import "./player.css";
const AVATARS = ["🌙", "🐈", "🩰", "🪽", "🍒", "🧸", "🪞", "🌷"];
const LEADS = [
  { id: "younghoon", name: "金泳勋", note: "克制温柔｜慢热的熟悉感" },
  { id: "hyunjae", name: "李贤在", note: "明朗可靠｜从朋友开始" },
  { id: "juyeon", name: "李柱延", note: "安静注视｜行动比语言先到" },
  { id: "changmin", name: "池昌民", note: "灵动直球｜轻松日常里的心动" },
  { id: "sunwoo", name: "金善旴", note: "锋利又细腻｜暧昧拉扯" },
  { id: "youngjae", name: "孙英宰", note: "温和有分寸｜逐渐靠近" },
];
type PlayerProfile = { avatar: string; name: string; signature: string; lead: string };
function StoryPlayer() {
  const [work, setWork] = useState<Work | null>(null),
    [error, setError] = useState("");
  const [profile, setProfile] = useState<PlayerProfile>(() => {
    try {
      const saved = localStorage.getItem("foundphone-player-profile");
      if (saved) return JSON.parse(saved) as PlayerProfile;
    } catch { /* ignore invalid local profile */ }
    return { avatar: AVATARS[0], name: "", signature: "今天也要好好生活。", lead: "" };
  });
  const [started, setStarted] = useState(false);
  useEffect(() => {
    const abort = new AbortController();
    fetch(
      new URLSearchParams(location.search).get("preview") === "test"
        ? "./test-work.json"
        : new URLSearchParams(location.search).get("template") === "blank"
          ? "./blank-work.json"
          : "./work.json",
      { signal: abort.signal },
    )
      .then((r) => {
        if (!r.ok) throw Error("缺少作品文件，请运行 npm run story:build");
        return r.json();
      })
      .then((x) => {
        const w = validateWork(x);
        document.title = "与你的故事 · FoundPhone Studio";
        setWork(w);
      })
      .catch((e) => {
        if (e.name !== "AbortError") setError(String(e));
      });
    return () => abort.abort();
  }, []);
  const beginStory = () => {
    if (!work || !profile.name.trim() || !profile.lead) return;
    const lead = LEADS.find((item) => item.id === profile.lead)!;
    const customized = validateWork({
      ...work,
      title: `与你的故事 · ${lead.name}`,
      phone: { ...work.phone, owner: profile.name.trim() },
      variables: {
        ...work.variables,
        playerName: profile.name.trim(),
        playerAvatar: profile.avatar,
        playerSignature: profile.signature.trim(),
        selectedLead: lead.id,
        selectedLeadName: lead.name,
      },
    });
    try { localStorage.setItem("foundphone-player-profile", JSON.stringify(profile)); } catch { /* storage may be unavailable */ }
    setWork(customized);
    setStarted(true);
  };
  return (
    <main className="story-runtime">
      {work && started ? (
        <Phone work={work} />
      ) : work ? (
        <section className="fp-onboarding" aria-label="创建你的手机资料">
          <div className="fp-kicker">FOUND PHONE STUDIO · STORY 01</div>
          <h1>先创建你的手机资料</h1>
          <p className="fp-subtitle">从你的 KakaoTalk 个人资料开始，再选择想要开启的故事。资料会保存在当前浏览器。</p>
          <div className="fp-section-title">01 / 选择头像</div>
          <div className="fp-avatars">
            {AVATARS.map((avatar) => (
              <button className="fp-avatar" key={avatar} type="button" aria-label={`选择头像 ${avatar}`} aria-pressed={profile.avatar === avatar} onClick={() => setProfile({ ...profile, avatar })}>{avatar}</button>
            ))}
          </div>
          <div className="fp-section-title">02 / 昵称</div>
          <input className="fp-field" value={profile.name} maxLength={24} placeholder="输入你的 KKT 显示名称" onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
          <div className="fp-section-title">03 / 状态签名</div>
          <input className="fp-field" value={profile.signature} maxLength={80} placeholder="写一句个人签名" onChange={(e) => setProfile({ ...profile, signature: e.target.value })} />
          <div className="fp-section-title">04 / 选择故事男主</div>
          <div className="fp-leads">
            {LEADS.map((lead) => (
              <button className="fp-lead" key={lead.id} type="button" aria-pressed={profile.lead === lead.id} onClick={() => setProfile({ ...profile, lead: lead.id })}>
                <span className="fp-lead-name">{lead.name}</span>
                <span className="fp-lead-note">{lead.note}</span>
              </button>
            ))}
          </div>
          <button className="fp-start" type="button" disabled={!profile.name.trim() || !profile.lead} onClick={beginStory}>创建资料，进入故事 ↗</button>
          <p className="fp-small-note">当前版本先接入资料创建与男主选择入口；六位男主的专属肖像和完整独立剧情还需要进一步加入作品数据。</p>
        </section>
      ) : (
        <p role="status">{error || "正在打开手机…"}</p>
      )}
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<StoryPlayer />);
